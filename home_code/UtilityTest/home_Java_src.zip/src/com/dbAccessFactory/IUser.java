package com.dbAccessFactory;

public interface IUser {
    void insert(User user);
    User getUser(int id);
}
