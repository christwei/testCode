package com.utility;

public class BeanCopy {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Person per = new Person();
        
        //BeanUtils
    }
}

class Person {
    public Person() {
    }
}
