package com.utility;

public class UtiTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Simple a = new Simple();
		Simple b = new Simple();
		System.out.println(a==b);
	}

}


class Simple {
	Simple(){
		
	}
}