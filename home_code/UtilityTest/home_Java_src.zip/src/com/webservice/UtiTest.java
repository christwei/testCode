package com.webservice;

public class UtiTest {

	class A {
		int i;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		int j= i++ +5;
		System.out.println(j);
		
		JxSendSmsTest netObj = new JxSendSmsTest();
		
		try {
			netObj.sendSms();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

class B {
	int i;
}
